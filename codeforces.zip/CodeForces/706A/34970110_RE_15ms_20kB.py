import math


class Point:
    def __init__(self, lista):
        a, b = lista
        self.x = a
        self.y = b

    def distance(self, point):
        a = point.x
        b = point.y
        return math.sqrt((self.x-a)**2 + (self.y - b)**2)


class Taxi:
    def __init__(self, lista):
        a, b, velocidade = lista
        print(a, b, velocidade)
        self.posicao = Point([a, b])
        self.velocidade = velocidade


def converteInput(a):
    return list(map(float, a.split(' ')))


vasily = Point(converteInput(input()))
qtd_taxis = int(input())
taxis = []
for x in range(qtd_taxis):
    taxis.append(Taxi(converteInput(input())))

tempo = math.inf
for taxi in taxis:
     t = vasily.distance(taxi.posicao) / taxi.velocidade 
     if t < tempo:
         tempo = t

print(t)
