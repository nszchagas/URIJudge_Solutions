from cmath import sqrt
import math


x, y = list(map(float, input().split(' ')))
qtd_taxis = int(input())
tempo = math.inf

for i in range(qtd_taxis):
    a, b, v = list(map(float, input().split(' ')))
    d = math.sqrt((x-a)**2 + (y - b)**2)
    t = d / v
    if t < tempo:
        tempo = t

print(t)
