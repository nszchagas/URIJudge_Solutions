#include <bits/stdc++.h>
using namespace std;
using ll = long long int;

const ll MAX{100'010};

vector<ll> adj[MAX];
ll n, m, total = 0;
ll cats[MAX];

bitset<MAX> visited;

void dfs(ll u, ll sum)
{
    if (visited[u])
        return;

    visited[u] = 1;

    if (cats[u])
        sum++;
    else
        sum = 0;

    if (sum > m)
        return;

    if (u != 1 && adj[u].size() == 1)
    {
        total++;
    }

    for (auto v : adj[u])
        dfs(v, sum);
}
int main()
{
    cin >> n >> m;

    for (ll i = 1; i <= n; i++)
        cin >> cats[i];

    ll a, b;
    for (ll i = 1; i < n; i++)
    {
        cin >> a >> b;
        adj[a].emplace_back(b);
        adj[b].emplace_back(a);
    }

    dfs(1, 0);

    cout << total;
    return 0;
}