#include <bits/stdc++.h>
using namespace std;

const int MAX{10'001};
int cats[MAX];
vector<int> adj[MAX];
bitset<MAX> visited;

int n, m_cats, total = 0;

void dfs(int u, int sum)
{
    if (visited[u])
        return;

    visited[u] = true;

    if (cats[u])
        sum++;
    else
        sum = 0;

    // cout << "Consecutive cats until " << u << " = " << sum << endl;

    if (sum > m_cats)
        return;

    if (adj[u].size() == 1 && u != 1)
        total++;

    for (auto v : adj[u])
        dfs(v, sum);
}
int main()
{
    cin >> n >> m_cats;

    for (int i = 1; i <= n; i++)
        cin >> cats[i];

    for (int i = 1; i < n; i++)
    {
        int a, b;
        cin >> a >> b;

        adj[a].emplace_back(b);
        adj[b].emplace_back(a);
    }

    // for (int i = 0; i <= n; i++)
    // {
    //     printf("cats[%d]=%d\nadj[%d]= ", i, cats[i], i);
    //     for (auto x : adj[i])
    //         cout << x << " ";
    //     cout << '\n';
    // }

    // for (int i = 1; i <= n; i++)
    // {
    //     cout << i << "(" << cats[i] << "): ";

    //     if (adj[i].size() > 0)
    //     {
    //         for (auto y : adj[i])
    //             cout << y << " ";
    //     }
    //     cout << endl;
    // }

    dfs(1, 0);

    cout << total;
    return 0;
}