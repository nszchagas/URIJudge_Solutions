#include <bits/stdc++.h>
using namespace std;
using ii = pair<int, int>;

const int MAX{200'001};
const int oo{200'000'000};

vector<ii> edges;
int dg[MAX];

int N, M;

int main()
{
    memset(dg, 0, sizeof(dg));

    cin >> N >> M;
    int A, B;
    for (int i = 0; i < M; i++)
    {
        cin >> A >> B;

        dg[A]++;
        dg[B]++;

        edges.emplace_back(ii(A, B));
    }

    int total_groups = 0;
    int group = 0;
    do
    {

        vector<ii> r;

        for (size_t i = 0; i < edges.size(); i++)
        {

            auto [a, b] = edges[i];
            if (dg[a] == 1 || dg[b] == 1)
            {
                auto s = (a == 1) ? a : b;
                r.emplace_back(ii(s, i));
                group = 1;
            }
        }
        group = r.size() > 0;
        for (auto [s, i] : r)
        {
            auto [a, b] = edges[i];
            dg[a]--;
            dg[b]--;
            edges.erase(next(edges.begin(), i));
        }
        total_groups += group;
    } while (edges.size() && group);

    cout << total_groups << '\n';
    return 0;
}