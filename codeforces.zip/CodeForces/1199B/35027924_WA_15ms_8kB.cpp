#include <iostream>

using namespace std;

int main()
{
    long int H, L;
    cin >> H >> L;
    long long int x = (L + H) * (L - H);
    double y = x / (2 * H);

    cout << y;

    return 0;
}
