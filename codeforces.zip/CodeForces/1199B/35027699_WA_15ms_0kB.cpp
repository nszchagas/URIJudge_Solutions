#include <iostream>

using namespace std;

int main()
{
    int L, H;
    cin >> H >> L;

    auto x = (double)(L - H) * (L + H) / (2 * H);
    cout << x;

    return 0;
}
