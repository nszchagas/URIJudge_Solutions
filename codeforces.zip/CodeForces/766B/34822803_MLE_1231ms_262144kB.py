from itertools import combinations


n = int(input())
lines = list(map(int, input().split(' ')))

def formaTriangulo(triple):
    a, b, c = triple
    return a < b + c and b < a + c and c < a + b

def getTriples(list):
    return set(combinations(list, 3))

def solve(lines):
    for triple in getTriples(lines):
        if formaTriangulo(triple):
            return 'YES'
    return 'NO'

print(solve(lines))

    