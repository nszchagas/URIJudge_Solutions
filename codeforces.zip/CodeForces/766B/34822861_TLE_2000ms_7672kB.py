from itertools import combinations


n = int(input())
lines = list(map(int, input().split(' ')))

def solve(lines):
    for triple in combinations(lines, 3):
        a, b, c = triple
        if a < b + c and b < a + c and c < a + b:
            return 'YES'
    return 'NO'

print(solve(lines))

    