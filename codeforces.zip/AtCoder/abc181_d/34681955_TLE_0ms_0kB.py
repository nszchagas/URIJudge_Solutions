from itertools import permutations

S = list(input())


def isMultipleOfEight(number):

  lastDigits = ''.join(number[-3:])
  return int(lastDigits) % 8 == 0

def hasMultipleOfEight(S):
  perm = permutations(S, len(S))
  for number in perm:
    if (isMultipleOfEight(number)):
      return True
  return False

if(hasMultipleOfEight(S)):
  print('Yes')
else:
  print('No')

