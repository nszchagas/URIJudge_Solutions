from itertools import permutations

S = input()

def hasMultipleOfEight(S):
  for x in set(permutations(S, len(S))):
    if (int(''.join(x)) % 8 == 0):
      return True
  return False

if(hasMultipleOfEight(S)):
  print('Yes')
else: 
  print('No')
