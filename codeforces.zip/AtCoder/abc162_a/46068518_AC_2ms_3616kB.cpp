#include <bits/stdc++.h>
using namespace std;

int main()
{
    string num;
    cin >> num;

    cout << ((num.find('7') <= num.length()) ? "Yes" : "No");

    return 0;
}