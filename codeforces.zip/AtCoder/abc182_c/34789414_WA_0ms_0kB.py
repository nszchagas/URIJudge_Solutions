from itertools import combinations
from operator import truediv


n = int(input().strip())

def sumList(list):
    sum = 0
    for x in list:
        sum+= x
    return sum


def getSumFromDigits(number, sum):
    listOfDigits = [int(x) for x in str(number)]
    if sum in listOfDigits:
        return 1
    else: 
        for i in range(2, len(listOfDigits)-1):
            for comb in combinations(listOfDigits, i):
                if sumList(comb) == sum:
                    return i
    return -1
                


def numberOfRemovals(n):
    remainder = n % 3
    if remainder == 0:
        return 0
    elif remainder == 1:
        for x in [1, 4, 7]: 
            changes = getSumFromDigits(n, x)
            if changes != -1:
                return changes
        return -1
    elif remainder == 2:
        for x in [2, 5, 8]: 
            changes = getSumFromDigits(n, x)
            if changes != -1:
                return changes
        return -1

print(numberOfRemovals(n))


