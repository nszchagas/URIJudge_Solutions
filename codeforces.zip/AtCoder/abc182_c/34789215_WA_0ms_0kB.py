n = list(map(int, input().strip()))

def sumDigits(listOfDigits):
    sum = 0
    if len(listOfDigits) > 1:
        for dig in listOfDigits:
            sum+= dig
    return sum

def numberOfRemovals(listOfDigits):
    remainder = sumDigits(listOfDigits) % 3 
    if remainder == 0:
        return 0
    elif remainder == 1:
        if 1 in listOfDigits or 4 in listOfDigits or 7 in listOfDigits:
            return 1
        else:
            return -1
    elif remainder == 2:
        if 2 in listOfDigits or 5 in listOfDigits or 8 in listOfDigits:
            return 1
        else:
            return -1

print(numberOfRemovals(n))


