from itertools import combinations


def verifyCollinearityThreePoints(pointsList): # a = (x1, y1), b = (x2, y2), c = (x3, y3)
  x1, y1 = map(int, pointsList[0].split(' '))
  x2, y2 = map(int, pointsList[1].split(' '))
  x3, y3 = map(int, pointsList[2].split(' '))
  if (x1 == x2 and x2 == x3):
    return True
  elif (y1 == y2 and y2 == y3):
    return True
  else: 
    return ((y1-y2)*(x2-x3)) == ((y2-y3)*(x1-x2))


points = []
n = int(input())
for x in range(n):
  points.append(input())

comb = combinations(points, 3)

def verifyCollinearity(combinations):
  for x in combinations: 
    if verifyCollinearityThreePoints(x):
      return True
  return False

if(verifyCollinearity(comb)):
  print('Yes')
else:
  print('No') 

