#include <iostream>

using namespace std;

int main()
{
    int qtdJogadas, dado1, dado2, sequenciaIguais = 0;
    string res = "No";
    cin >> qtdJogadas;
    for (int i = 0; i < qtdJogadas; i++)
    {
        cin >> dado1 >> dado2;
        if (res == "No")
        {
            if (dado1 == dado2)
                sequenciaIguais++;
            else
                sequenciaIguais = 0;
            if (sequenciaIguais == 3)
                res = "Yes";
        }
    };
    cout << res;
    return 0;
}
