import math


n = input()
list = list(map(int, input().split(' ')))

m, e, c = 0, 0, 0 

c = max(map(abs, list))

for x in list:
    m += abs(x)
    e += x**2 

e = math.sqrt(e)

print(m)
print(e)
print(c)
