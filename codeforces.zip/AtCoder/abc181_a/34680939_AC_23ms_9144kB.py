n = int(input())

if n%2 == 0: 
  print('White')
else:
  print('Black')