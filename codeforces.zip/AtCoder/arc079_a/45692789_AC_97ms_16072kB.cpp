#include <bits/stdc++.h>
using namespace std;

const int MAX{200'001};
const int oo{200'000'000};
const int MAX_DIST{2};

vector<int> adj[MAX];
int N;

string bfs(int u)
{
	vector<int> dist(N + 1, oo);
	queue<int> q;

	dist[u] = 0;
	q.push(u);

	while (not q.empty())
	{
		// Get next neighbour to visit, without removing from queue.
		auto u = q.front();

		// Removes from queue.
		q.pop();

		// cout << "Visiting " << u << " which has dist: " << dist[u] << '\n';
		if (u == N and dist[u] <= MAX_DIST)
			return "POSSIBLE";

		for (auto v : adj[u])
		{
			if (dist[v] == oo)
			{
				dist[v] = dist[u] + 1;
				q.push(v);
			}
		}
	}
	return "IMPOSSIBLE";
}

int main()
{
	int M;
	cin >> N >> M;
	int A, B;
	while (M--)
	{
		cin >> A >> B;
		adj[A].emplace_back(B);
		adj[B].emplace_back(A);
	}
	cout << bfs(1) << '\n';

	return 0;
}