
n = int(input())
sum = 0;
for i in range(n):
  a, b = map(int, input().split(' '))
  sum+= (a+b)*(b+1-a)/2

print(int(sum))