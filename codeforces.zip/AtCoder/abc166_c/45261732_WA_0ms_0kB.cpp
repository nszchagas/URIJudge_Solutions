#include <stdio.h>
#include <vector>

typedef struct observatory
{
    int height;
    int is_good;

} observatory;

int main()
{
    int qt_obs, qt_roads;
    scanf("%d %d", &qt_obs, &qt_roads);
    observatory obs[qt_obs];

    for (int i = 0; i < qt_obs; i++)
    {
        obs[i].is_good = 1;
        scanf("%d", &obs[i].height);
    }
    int temp = 0;

    while (qt_roads--)
    {
        int a, b;
        scanf("%d %d", &a, &b);
        a--, b--;
        if (obs[a].height <= obs[b].height)
        {
            obs[a].is_good = 0;
            if (obs[a].height == obs[b].height)
                obs[b].is_good = 0;
        }
    }

    int good_obs = 0;
    for (observatory o : obs)
        good_obs += o.is_good;

    printf("%d\n", good_obs);
    return 0;
}
