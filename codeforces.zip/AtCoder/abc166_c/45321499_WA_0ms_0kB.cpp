#include <bits/stdc++.h>
using namespace std;

// Cada observatório contém uma altura (long ing) e se é bom ou não (bit).
using ob = pair<long int, int>;
map<int, ob> obs;

int main()
{

    // n observatórios, m estradas.
    long int n, m;

    cin >> n >> m;

    for (int i = 1; i <= n; i++)
    {
        cin >> obs[i].first;
        obs[i].second = 1;
    }

    for (int i = 0; i < m; i++)
    {
        long int a, b;
        cin >> a >> b;
        long int diff = obs[a].first - obs[b].first;
        if (diff < 0)
            obs[a].second = 0;
        else if (diff == 0)
        {
            obs[a].second = 0, obs[b].second = 0;
        }

        // cout << obs[a].first << ' ' << obs[b].first << ' ' << diff << "\n";
    }

    long int total = 0;
    for (int i = 1; i <= n; i++)
    {
        // cout << i << '=' << obs[i].second << '\n';
        total += obs[i].second;
    }
    cout << total << '\n';

    return 0;
}