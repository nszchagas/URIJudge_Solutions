n, a, b = list(map(int, input().split(' ')))

print(n-a+b)