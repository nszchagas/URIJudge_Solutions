n = int(input())
path = list(map(int, input().split(' ')))

position = 0
maxPosition = 0

position += path[0]
if position > maxPosition:
    maxPosition = position 

for iteracao in range(1,n):
    for passo in path[:iteracao+1]:
        position += passo
        if position > maxPosition:
            maxPosition = position 

print(maxPosition)