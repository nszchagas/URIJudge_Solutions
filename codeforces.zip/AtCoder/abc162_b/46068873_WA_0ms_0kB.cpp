#include <bits/stdc++.h>
using namespace std;

int main()
{
    int num;
    cin >> num;

    const int nums[] = {1, 2, 0, 4, 0, 0, 7, 8, 0, 0, 11, 0, 13, 14, 0};

    int top = num % 15;
    int times = num / 15;

    int sum = 0;

    for (int i = 0; i < top; i++)
        sum += nums[i] + 15 * times;

    // cout << "sum until " << top << ": " << sum << " cicles: " << times << endl;

    for (int i = 0; i < times; i++)
    {
        sum += 60 + 15 * i * 8;
    }

    cout << sum;
    return 0;
}