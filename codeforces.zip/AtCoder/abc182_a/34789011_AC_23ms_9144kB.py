a, b = map(int, input().split(' '))

print(2*a+100-b)