n = int(input())
elements = list(map(int, input().split(' ')))
ks = list(range(2, max(elements)))
gcds = [0]*len(ks)

for i in range(len(ks)):
    for x in elements: 
        if x%ks[i] == 0:
            gcds[i]+=1

print(ks[gcds.index(max(gcds))])

