# incluir caso em que n == 1
n = input()

elements = list(map(int, input().strip().split(' ')))
ks = list(range(2, 1000+1))

gcds = [0]*len(ks)

for i in range(len(ks)):
    for x in elements: 
        if x%ks[i] == 0:
            gcds[i]+=1
print(ks[gcds.index(max(gcds))])

