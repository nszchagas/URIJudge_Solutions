#include <stdio.h>
#include <string>
#include <iostream> 

using namespace std;

int main()
{
    string word;
    getline(cin, word);
    if (word.at(word.length() - 1) != 's')
    {
        word.append("s");
    }
    else
        word.append("es");

    cout << word;
    return 0;
}