#include <bits/stdc++.h>
using namespace std;

// Cada observatório contém uma altura (long ing) e se é bom ou não (bit).
typedef struct observatory
{
    long int height;
    int is_good;
} observatory;

map<int, observatory> obs;

int main()
{
    // n observatórios, m estradas.
    long int n, m;
    long int total = 0;

    cin >> n >> m;

    for (int i = 1; i <= n; i++)
    {
        cin >> obs[i].height;
        obs[i].is_good = 1;
    }
    for (int i = 0; i < m; i++)
    {
        long int a, b;
        cin >> a >> b;
        long int diff = obs[a].height - obs[b].height;
        if (diff < 0)
            obs[a].is_good = 0;
        else if (diff == 0)
            obs[a].is_good = 0, obs[b].is_good = 0;
        else
            obs[b].is_good = 0;
    }

    for (int i = 1; i <= n; i++)
        total += obs[i].is_good;
    cout << total << '\n';

    return 0;
}
