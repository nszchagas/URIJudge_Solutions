import math


testCases = int(input())

def norma(x, y):
    return math.sqrt(x**2 + y**2)

for cont in range(testCases):
    x, y, r = list(map(int, input().split(' ')))
    biggest = norma(x, y) + r
    smallest = 2*r - biggest
    print(f'{smallest:.2f} {biggest:.2f}')
