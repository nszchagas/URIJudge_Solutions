t = int(input())

for i in range(t):
    n = int(input())
    if n%4 == 0:
        print('YES')
    else:
        print('NO')