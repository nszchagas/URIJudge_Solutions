#include <bits/stdc++.h>
using namespace std;

const int MAX{200'001};
const int oo{200'000'000};
const int MAX_DIST{2};

vector<int> adj[MAX];

int N;

void bfs(int u)
{
    vector<int> dist(N + 1, oo);
    queue<int> q;
    queue<int> reprimands;

    dist[u] = 0;
    q.push(u);

    while (not q.empty())
    {
        auto u = q.front();
        q.pop();

        cout << u << " has " << adj[u].size() << " ties.\n";
        for (auto v : adj[u])
        {
            if (adj[v].size() == 1)
            {
                cout << "reprimanding " << v << '\n';
                reprimands.push(u);

                cout << v << " is tied to " << u << '\n';

                cout << "Removing " << v << " from ties at " << u << '\n';
                cout << "adj[" << u << "]: ";
                for (auto x : adj[u])
                    cout << x << ' ';
                cout << '\n';

                adj[u].erase(remove(adj[u].begin(), adj[u].end(), v), adj[u].end());
                adj[v] = {};

                cout << "adj[" << u << "]: ";
                for (auto x : adj[u])
                    cout << x << ' ';
                cout << " (size: " << adj[u].size() << ")\n";
            }

            if (dist[v] == oo)
            {
                dist[v] = dist[u] + 1;
                q.push(v);
            }
        }
    }
}

int main()
{
    int M;
    cin >> N >> M;
    int A, B;
    int sol = 0;
    while (M--)
    {
        cin >> A >> B;
        adj[A].emplace_back(B);
        adj[B].emplace_back(A);
    }

    while (1)
    {
        vector<int> reprimands;
        int qt_reprimands = 0;

        for (int i = 1; i <= N; i++)
        {
            if (adj[i].size() == 1)
            {
                reprimands.emplace_back(i);
                qt_reprimands++;
            }
        }
        if (qt_reprimands == 0)
            break;

        sol++;
        for (int i = 0; i < qt_reprimands; i++)
        {
            int curr = reprimands[i];
            int viz = adj[curr][0];
            adj[curr].clear();
            adj[viz].erase(remove(adj[viz].begin(), adj[viz].end(), curr), adj[viz].end());
        }
    }

    cout << sol;

    return 0;
}