#include <bits/stdc++.h>
using namespace std;

const int MAX{10'001};
const int oo{10'002};

int n;
int ans = 0;
vector<int> adj[MAX];
int color[MAX];

bitset<MAX> visited;

void dfs(int child, int par)
{

    if (visited[child])
        return;

    visited[child] = true;

    // cout << "Visiting " << child << "\n";
    // cout << "Color child (" << child << "): " << color[child] << " Parent (" << par << ") :" << color[par] << endl;
    // cout << "Is different color? " << (color[child] != color[par]) << endl;
    ans += (color[child] != color[par]);
    for (auto v : adj[child])
    {
        dfs(v, child);
    }
}

int main()
{
    cin >> n;

    for (int i = 2; i <= n; i++)
    {
        int temp;
        cin >> temp;

        adj[i].emplace_back(temp);
        adj[temp].emplace_back(i);
    }

    for (int i = 1; i <= n; i++)
        cin >> color[i];

    // for (int i = 1; i <= n; i++)
    // {
    //     cout << i << "(" << color[i] << "): ";

    //     if (adj[i].size() > 0)
    //     {
    //         for (auto y : adj[i])
    //             cout << y << " ";
    //     }
    //     cout << endl;
    // }

    dfs(1, 0);
    cout << ans;

    return 0;
}